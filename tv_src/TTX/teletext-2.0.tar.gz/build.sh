#!/bin/sh
powerpc-TiVo-linux-gcc -Wall -O99 -s -o teletext teletext.c "$@"
