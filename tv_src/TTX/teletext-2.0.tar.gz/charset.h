/*
 * charset.h 1.0  $Id: charset.h,v 1.2 2005/08/30 23:34:06 maxwells_daemon Exp $
 * http://homepage.ntlworld.com/maxwells.daemon/tivo/teletext.html
 *
 * Based on tables 35 and 36 from the
 * Teletext standard (ETSI EN 300 706 v1.2.1 (2003-04-16))
 *   http://webapp.etsi.org/exchangefolder/en_300706v010201p.pdf
 */

#ifndef CHARSET_H
#define CHARSET_H 1

// Characters that have national option subsets.
// Value gives index into each charset array, or 0 if no translation.
static const size_t charset_pos[128]= {
  [0x23] =  1,
  [0x24] =  2,
  [0x40] =  3,
  [0x5B] =  4,
  [0x5C] =  5,
  [0x5D] =  6,
  [0x5E] =  7,
  [0x5F] =  8,
  [0x60] =  9,
  [0x7B] = 10,
  [0x7C] = 11,
  [0x7D] = 12,
  [0x7E] = 13,
  [0x7F] = 14   // needs translation, even if it isn't a national subset character
};

// Closest ASCII equivalents of national option subset characters.
// First character of each is \0 since indices start at 1.
static const Byte charset[0x16][15]= {
  [0] = "\0#$@<?>^#-?|??#",  // English
  [1] = "\0#$SAOU^_\"aous#", // German
  [2] = "\0#$EAOAU_eaoau#",  // Swedish/Finnish
  [3] = "\0#$e\"c>^#uaoei#", // Italian
  [4] = "\0eiaeeui#eaouc#",  // French
  [5] = "\0c$iaeiou?unea#",  // Portuguese/Spanish
  [6] = "\0#uctzyireaeus#",  // Czech/Slovak
  [7] = "\0#$TASAIitasai#",  // Rumanian
};

#endif
