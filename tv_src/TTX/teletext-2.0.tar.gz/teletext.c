/*
 * teletext 2.0  $Id: teletext.c,v 1.23 2005/08/31 01:25:43 maxwells_daemon Exp $
 * Decodes, selects, and displays teletext packets and pages from the
 * input stream of a UK Thomson TiVo. For information, documentation,
 * acknowledgements, and copyright information, see
 *   http://homepage.ntlworld.com/maxwells.daemon/tivo/teletext.html
 * Brief help can be ontained with the command: teletext -h
 */

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <getopt.h>
#include <assert.h>
#include <limits.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <setjmp.h>

typedef unsigned char          Byte;
typedef unsigned long int      Addr_t;
typedef unsigned long long int Count_t;

#ifdef SMALL
#define NO_HELP
#endif
#include "names.h"
#include "charset.h"
#include "code.h"

#define FPGA_FILE "/proc/fpga"
#define KMEM_FILE "/dev/kmem"
#define MAXSYNC 100
#define FRAMELEN 48
#define MINLINE  2
#define MAXLINE 23
#define PKTID_NULL { -1, -1, -1, -1, -1 }
#define MAXROW 24
#define MAGAZINES 8
#define SHOWHEAD 8

#define sputs(s) fputs ((s), stdout)

static Addr_t fpga_base, vbi_start, vbi_end, vbi_len, vbi_ptr, vbi_next= 0;
static int verbose= 0, showerr= 0, skipblank= 1, bypage= 0, onlypages= 0, colour= 0, full= 0, pdcdelta= 0, dotimestamp= 0;
static int addborder= 1, dblheight= 0;
static Count_t npkt= 0, nsel= 0, nsoft= 0, nparity= 0, nhard= 0, nblank= 0, ndecode= 0;
static double totsecs= 0.0;
static int scanline= -1, field= -1, check_missing= 0, lost= -1;
static int missing_lines[MAXLINE+1]= {}, linetypes[2][MAXLINE+1];
static Count_t linecount[2][MAXLINE+1]= {}, packetcount[32]= {};
static time_t timestamp= 0;
static int tz= 0;

static jmp_buf clean_exit;
static volatile sig_atomic_t doing_colour= 0, last_signal= 0;

typedef struct {
  int X, Y, P, S, D;
} Pktid_t;
static const Pktid_t pktid_null= PKTID_NULL;
static Pktid_t *pktid_sel;
static size_t npktid_sel= 0;

typedef struct {
  Count_t pkt;
  Addr_t addr;
  time_t timestamp;
  Byte frame[FRAMELEN];
  Byte present, scanline, field;
} Line_t;
typedef struct {
  Pktid_t pktid;
  Line_t line[MAXROW+1];
  Byte started, lang, flags;
} Page_t;
static Page_t* pages= NULL;

static void usage (const char* prog)
{
  const char *p;
  for (p= prog; *p; p++)
    if (*p == '/') prog= p+1;
  printf ("\
%s - decodes, selects, and displays teletext packets on a UK Thomson TiVo\n\
  http://homepage.ntlworld.com/maxwells.daemon/tivo/teletext.html\n\
", prog);
#ifndef NO_HELP
  printf ("\
\n\
Usage:  %s [OPTIONS] [PACKET-SELECTIONS]\n\
\n\
Where OPTIONS are:\n\
  -f      show full teletext packet information. Parity errors shown as ~\n\
  -p      show only full pages for packets 0-24\n\
  -P      like -p, but also displays other packets\n\
  -z      show only changes in X8/30.1 (PDC) packets\n\
  -c      show teletext formatting using ANSI colour codes\n\
  -o      use existing buffer contents\n\
  -O      only use existing buffer contents\n\
  -C      continuous running\n\
  -v      verbose running for debugging (-vv for extra verbose)\n\
  -q      quiet: don't display packets (useful to get statistics)\n\
  -e      show errors\n\
  -n NUM  without -p: stop after displaying NUM packets (default=25 if no -N)\n\
  -n NUM  with    -p: stop after displaying NUM pages   (default=1  if no -N)\n\
  -N NUM  stop after reading NUM packets\n\
  -m      check for missing scan-lines\n\
  -M LIST check for missing scan-lines, apart from the ones listed, eg -M 22e,23\n\
  -b      decode blank lines\n\
  -s      show statistics summary at the end\n\
  -t SECS time to wait between each read (default=0.5s, data loss if >5s)\n\
  -T      display local timestamps based on X8/30.0 (BSDP) packets\n\
\n\
The optional PACKET-SELECTIONS are of the form [[Xn|[P]nnn][:nnnn][/nn][.d]]\n\
Only packets matching all the criteria in any of the space-separated selections\n\
are displayed. The components are magazine (Xn), page number (Pnnn),\n\
subpage (:nnnn), packet (/nn), and designation code (.d).\n\
", prog);
#endif
}

static void showbuf (Addr_t addr, const Byte* buf, size_t lbuf)
{
  const size_t nw=       FRAMELEN/2;
  const size_t nhead=    SHOWHEAD*FRAMELEN;
  const size_t itail=    lbuf > nhead ? (((lbuf+(FRAMELEN-1))/FRAMELEN)*FRAMELEN - nhead) : 0;
  const Byte*  end=      buf +lbuf;
  const Byte*  tail=     buf +itail;
  const Addr_t tailaddr= addr+itail;
  size_t nl= 0;

  assert (addr>=vbi_start);
  assert (addr+lbuf<=vbi_end);
  if (addr==vbi_start) puts ("--- wrap around buffer ---");
  while (buf<end) {
    size_t i;
    printf ("%08lX:", addr);
    for (i= 0; i<nw; i++) {
      if (buf>=end) break;
      printf (" %02X", *buf++);
      if (buf>=end) break;
      printf ("%02X",  *buf++);
    }
    putchar ('\n');
    nl++;
    addr += FRAMELEN;
    if (verbose <= 3 && nl==SHOWHEAD && buf<tail) {
      puts ("--");
      buf=  tail;
      addr= tailaddr;
    }
  }
}

static const Byte* findpacket (const Byte* start, const Byte* end)
{
  const Byte *q= start, *es, *lastsync= start+MAXSYNC, *lastcomplete= end-FRAMELEN;

  es= lastsync<lastcomplete ? lastsync : lastcomplete;
  do {
    if (q>es) {
      if (q>lastsync) {
        ndecode++;
        if (showerr) puts ("lost sync [decode error]");
      }
      return 0;
    }
  } while (*q++ != 0x8A);
  return q-1;
}

static int badhamm (int err, Addr_t addr, const Pktid_t* pktid)
{
  nsoft += ((err&0x0F00)>>8);
  nhard += ((err&0xF000)>>12);
  if (err & 0xf000) {
    if (showerr)
      printf ("%08lX: bad hamming in %X/%u packet: %u/%u soft/hard errors [hamm error]\n",
               addr,  pktid->X, pktid->Y, (err&0x0F00)>>8, (err&0xF000)>>12);
    return 1;
  }
  return 0;
}

static void checksync (Addr_t addr, const Byte* q, const Pktid_t* pktid)
{
  // For some reason packets 8/0 to 8/24 can have a variable data count (q[1])
  // instead of the standard 0x4B (11*4=44 bytes in frame, with bit 6 set for
  // even parity). Perhaps TiVo somehow uses this to mark subtitle packets.
  // In this case, showpkt displays this byte in 'full' mode.
  if ( q[0] != 0x8A ||
      (q[1] != 0x4B && (pktid->X != 8 || pktid->Y > 24))) {
    ndecode++;
    if (showerr)
      printf ("%08lX: bad packet %X/%u frame header %02X%02X [decode error]\n",
              addr, (pktid->P == pktid_null.P ? pktid->X : pktid->P), pktid->Y, q[0], q[1]);
  }
}

static int print_time (time_t time)
{
  char atime[21];
  static const char blanks[21]= "                    ";
  if (!time) {
    sputs (blanks);
    return (sizeof(blanks)-1);
    // Use gmtime because we have already converted to local time zone
    // (not that localtime does anything different on TiVo)
  } else if (strftime (atime, sizeof(atime), "%e-%b-%Y %H:%M:%S", gmtime (&time))) {
    sputs (atime);
    return strlen (atime);
  } else {
    return printf ("time:%-15ld", time);
  }
}

static char charset_translate (Byte lang, Byte c)
{
  size_t pos;
  char cc;
  pos= charset_pos[c];
  if (!pos) return c;
  cc= charset[lang][pos];
  if (cc) return cc;
  cc= charset[0][pos]; // If language or language character not defined, use English
  if (cc) return cc;
  return c;            // If character not even in English, use original (should never get here)
}


static void format (const char* prefix, const Byte* p, size_t np, Byte lang, int subtitle)
{
  size_t i;
  Byte lastmosaic= ' ';
  int mosaic= 0, heldmosaic= 0, display= !subtitle;

  putchar ('|');
  if (prefix) sputs (prefix);
  for (i= 0; i<np; i++) {
    Byte c= p[i];
    if (odd_parity[c]) {
      Byte space= (display && mosaic && heldmosaic) ? lastmosaic : ' ';
      c &= 0x7F;
      switch (c) {
        case 0x10 ... 0x17: {  // mosaic foreground colours
          putchar (space);
          lastmosaic= ' ';
          mosaic= 1;
          break;
        }
        case 0x0A: {           // end box
          putchar (space);
          if (subtitle) display= 0;
          break;
        }
        case 0x0B: {           // start box
          putchar (space);
          if (subtitle && i+1<np && p[i+1]==0x0B) display= 1;
          break;
        }
        case 0x0C: {           // normal height
          putchar (space);
          lastmosaic= ' ';
          break;
        }
        case 0x0D: {           // double height (just skip next row if blank, even if cancelled later)
          putchar (space);
          dblheight= 1;
          lastmosaic= ' ';
          break;
        }
        case 0x1E: {           // hold mosaics
          putchar (display && mosaic ? lastmosaic : ' ');
          heldmosaic= 1;
          break;
        }
        case 0x1F: {           // release mosaics
          putchar (space);
          heldmosaic= 0;
          break;
        }
        default: {
          if (c<0x20) {        // other codes
            putchar (space);
          } else if (mosaic && c&0x20) {
            lastmosaic= (c==' ' ? ' ' : '#');
            putchar (display ? lastmosaic : ' ');
          } else if (display && c>=' ') {
            putchar (charset_translate (lang, c));
          } else {
            putchar (' ');
          }
          break;
        }
      }
    } else {
      nparity++;
      putchar (full ? '~' : ' ');
    }
  }
  putchar ('|');
}

#define CSI "\033["
#define STARTCOL CSI "40;37m"
#define   ENDCOL CSI "0m"
#define putcol(c)         putchar ('0'+(c))
#define putend()          putchar ('m')
#define setfg(fg)         (sputs (CSI "3"), putcol (fg), putend())
#define setbg(bg)         (sputs (CSI "4"), putcol (bg), putend())
#define setfgbgx(s,fg,bg) (sputs (CSI s "3"), putcol (fg), sputs (";4"), putcol (bg), putend())
#define setfgbg(fg,bg)    setfgbgx ("",   (fg), (bg))
#define reset(fg,bg)      setfgbgx ("0;", (fg), (bg))
#define setblink()        sputs (CSI "5m")
#define setbg0()          sputs (CSI "40m")
#define startcol()        sputs (STARTCOL)
#define endcol()          sputs (ENDCOL)

static void format_colour (const char* prefix, const Byte* p, size_t np, Byte lang, int subtitle)
{
  size_t i;
  Byte fgcolour= 7, bgcolour=  0, lastmosaic= ' ';
  int concealed= 0, flash= 0, mosaic= 0, heldmosaic= 0, blockon= 0, display= !subtitle;

  doing_colour= 1;
  if (display) startcol();
  if (prefix) sputs (prefix);
  for (i= 0; i<np; i++) {
    Byte c= p[i];
    if (odd_parity[c]) {
      Byte space= (display && mosaic && heldmosaic) ? lastmosaic : ' ';
      c &= 0x7F;
      if (concealed && (c&0x68)==0) {
        if (display) reset (fgcolour, bgcolour);
        concealed= 0;
      } else if (blockon && !(mosaic && (c&0x20) && c!=' ')) {
        setbg (bgcolour);
        blockon= 0;
      }
      switch (c) {
        case 0x00 ... 0x07: {  // alpha foreground colours
          putchar (space);
          lastmosaic= ' ';
          mosaic= 0;
          fgcolour= c;
          if (display) setfg (fgcolour);
          break;
        }
        case 0x10 ... 0x17: {  // mosaic foreground colours
          putchar (space);
          lastmosaic= ' ';
          mosaic= 1;
          fgcolour= c&0x07;
          if (display) setfg (fgcolour);
          break;
        }
        case 0x08: {           // flash
          putchar (space);
          flash= 1;
          if (display) setblink();
          break;
        }
        case 0x09: {           // steady
          flash= 0;
          if (display) reset (fgcolour, bgcolour);
          putchar (space);
          break;
        }
        case 0x0A: {           // end box
          putchar (space);
          if (subtitle) {
            display= 0;
            endcol();
          }
          break;
        }
        case 0x0B: {           // start box
          putchar (space);
          if (subtitle && i+1<np && p[i+1]==0x0B) {
            display= 1;
            setfgbg (fgcolour, bgcolour);
            if (flash || concealed) setblink();
          }
          break;
        }
        case 0x0C: {           // normal height
          putchar (space);
          lastmosaic= ' ';
          break;
        }
        case 0x0D: {           // double height (just skip next row if blank, even if cancelled later)
          putchar (space);
          dblheight= 1;
          lastmosaic= ' ';
          break;
        }
        case 0x18: {           // conceal (display as flashing)
          concealed= 1;
          if (display) setblink();
          putchar (space);
          break;
        }
        case 0x1C: {           // black background
          putchar (space);
          bgcolour= 0;
          if (display) setbg0();
          break;
        }
        case 0x1D: {           // new background
          bgcolour= fgcolour;
          if (display) setfgbg (fgcolour, bgcolour);
          putchar (space);
          break;
        }
        case 0x1E: {           // hold mosaics
          putchar (display && mosaic ? lastmosaic : ' ');
          heldmosaic= 1;
          break;
        }
        case 0x1F: {           // release mosaics
          putchar (space);
          heldmosaic= 0;
          break;
        }
        default: {
          if (c<0x20) {        // other codes
            putchar (space);
          } else if (mosaic && c&0x20) {
            lastmosaic= c;
            if (display && c!=' ' && !blockon) {
              setbg (fgcolour);
              blockon= 1;
            }
            putchar (' ');
          } else if (display && c>=' ') {
            putchar (charset_translate (lang, c));
          } else {
            putchar (' ');
          }
          break;
        }
      }
    } else {
      nparity++;
      if (blockon) setbg (bgcolour);
      putchar (full ? '~' : ' ');
    }
  }
  if (display) endcol();
  doing_colour= 0;
}

static size_t multichar (char c, size_t n)
{
  size_t i;
  for (i= 0; i<n; i++) putchar (c);
  return n;
}

static int showpkt (Count_t npkt, Addr_t addr, int scanline, int field, time_t time,
                    const Byte* q, const Pktid_t* pktid,
                    const char* prefix, int text, Byte lang, Byte flags)
{
  const Byte* p= q+4;
  size_t i;
  int nhead= 0;

  addborder= 1;
  if (full && lost > 0) {
    printf ("...\n");
    lost= 0;
  }
  if (dotimestamp) {
    nhead += print_time (time);
    putchar (' ');
    nhead++;
  }
  if (full) nhead += printf ("%06llu %08lX", npkt, addr);
  if (verbose >= 1) {
    for (i= 0; i<FRAMELEN; i += 2)
      printf (" %02X%02X", q[i], q[i+1]);
    putchar ('\n');
    multichar (' ', nhead);
  }

  if (full) {
    int cs, sum;
    // Infer SAV from the checksum. We included all the other bytes in our
    // checksum, so the difference is the missing SAV.
    // The first two byte ought to be 8A4B, but the second is modified for subtitles.
    for (sum=0x8A+0x4B, i= 2; i<46; i++) sum += q[i];
    sum &= 0x7F;
    cs= q[46]&0x7F;
    nhead += printf (" L%02d%s/%02X ", scanline, fieldname[field], (cs-sum)&0x7F);
  }
  if (full || !bypage) {
    if      (pktid->Y > 28)
      nhead += printf ("       X%X/%02u",   pktid->X, pktid->Y);
    else if (pktid->P == pktid_null.P)
      nhead += printf ("P%X??:????""/%02u", pktid->X, pktid->Y);
    else
      nhead += printf ("P%03X:%04X/%02u",   pktid->P, pktid->S, pktid->Y);
    if (pktid->D != pktid_null.D) {
      nhead += printf (".%u", pktid->D);
    }
    putchar (' ');
    nhead++;
  }
  if (text >= 0) {
    int subtitle= flags&(PG_NEWSFLASH|PG_SUBTITLE);
    if (colour)
      format_colour (prefix, p+text, 42-text, lang, subtitle);
    else
      format        (prefix, p+text, 42-text, lang, subtitle);
  } else {
    for (i= 2; i<42; i += 2)
      printf (" %02X%02X", q[i], q[i+1]);
  }
  if (full) {
    int badbytes;
    if ((pktid->X == 8 && pktid->Y <= 24) || q[1] != 0x4B)
      printf (" subtitle:%02X", q[1]);
    badbytes= (FRAMELEN-4) - (q[47]&0x7F);
    if (badbytes != 0)
      printf (" %d bad bytes", badbytes);
  }
  // printf (" head:%u", nhead);
  return nhead;
}

static void showhead (Byte lang, Byte flags)
{
  size_t i;
  Byte f;
  if (!full) return;
  printf (" %s", languages[lang]);
  for (i= 0, f= flags; f && i<sizeof(header_bits)/sizeof(header_bits[0]); i++, f>>=1)
    if ((f&1) && header_bits[i])
      printf (", %s", header_bits[i]);
}

static int showpage (const Page_t *page)
{
  size_t i, j, nshow= 0;
  size_t nhead= (full ? 37 : bypage ? 0 : 13) +
                (dotimestamp ? 21 : 0); // get actual header length later, but this should be correct for the initial border
  Pktid_t pktid= page->pktid;
  char sprefix[9];
  const char bwborder[]= "+----------------------------------------+";
  const char bwblank[]=  "|                                        |";
  const char coblank[]=  STARTCOL "                                        " ENDCOL;

  if (!page->started) return 0;
  for (i= 0, j= MAXROW+1; i<=MAXROW; i++) {
    const Line_t *line= &page->line[i];
    const char* prefix;
    int text;

    if (!line->present) continue;
    for (; j<i; j++) {
      multichar (' ', nhead);
      if (colour) {
        doing_colour= 1;
        puts (coblank);
        doing_colour= 0;
      } else
        puts (bwblank);
    }
    pktid.Y= i;
    if (i == 0) {
      if (page->flags&PG_SUPPHEADER) {
//      if (bypage) continue;
        prefix= "        ";
      } else {
        j= i+1;
        sprintf (sprefix, "  P%03X  ", pktid.P);
        prefix= sprefix;
      }
      text= 10;
    } else {
      prefix= NULL;
      text= 2;
      j= i+1;
    }
    if (addborder && !nshow) {
      if (colour)
        putchar ('\n');
      else {
        multichar (' ', nhead);
        puts (bwborder);
      }
    }
    dblheight= 0;
    nhead= showpkt (line->pkt, line->addr, line->scanline, line->field, line->timestamp,
                    line->frame, &pktid, prefix, text, page->lang, page->flags);
    if (dblheight) j++;   // don't show blank 2nd line of double-height line
    if (nshow==0) showhead (page->lang, page->flags);  // show on first row, even if that isn't the header
    putchar ('\n');
    nshow++;
  }
  if (nshow) {
    if (colour)
      addborder= 1;
    else {
      multichar (' ', nhead);
      puts (bwborder);
      addborder= 0;
    }
  }
  return (onlypages ? 1 : nshow);
}

static int failXY (const Pktid_t* pktid)
{
  size_t i;
  if (onlypages && pktid->Y > MAXROW) return 1;
  if (npktid_sel <= 0) return 0;
  for (i= 0; i < npktid_sel; i++)
    if ((pktid_sel[i].X == pktid_null.X || pktid->X == pktid_sel[i].X) &&
        (pktid_sel[i].Y == pktid_null.Y || pktid->Y == pktid_sel[i].Y) &&
        (pktid->Y <= 28 || (pktid_sel[i].P == pktid_null.P &&
                            pktid_sel[i].S == pktid_null.S)))
      return 0;
  return 1;
}

static int failP (const Pktid_t* pktid)
{
  size_t i;
  if (onlypages && pktid->Y > MAXROW) return 1;
  if (npktid_sel <= 0) return 0;
  for (i= 0; i < npktid_sel; i++)
    if ((pktid_sel[i].X == pktid_null.X || pktid->X == pktid_sel[i].X) &&
        (pktid_sel[i].Y == pktid_null.Y || pktid->Y == pktid_sel[i].Y) &&
        (pktid_sel[i].P == pktid_null.P || pktid->P == pktid_sel[i].P) &&
        (pktid_sel[i].S == pktid_null.S || pktid->S == pktid_sel[i].S) &&
        (pktid_sel[i].D == pktid_null.D || pktid->D == pktid_sel[i].D)) return 0;
  return 1;
}

static int decodepacket (const Byte *q, Addr_t addr)
{
  const Byte *p;
  int err = 0;
  int iderrs, newline, newfield, linetype, olinetype, text= 2;
  Byte XY;
  Pktid_t pktid;
  Byte lang=  0;            // language code
  Byte flags= 0;            // misc flags (see PG_xxx in vt.h)
  static int serial= 0;
  static int      PX[MAGAZINES+1]=    {-1, -1, -1, -1, -1, -1, -1, -1, -1};
  static int      SX[MAGAZINES+1]=    {-1, -1, -1, -1, -1, -1, -1, -1, -1};
  static Byte flagsX[MAGAZINES+1]=    {};
  static Byte  langX[MAGAZINES+1]=    {};
  static Pktid_t index= PKTID_NULL;

  // Check SAA7118 headers. q points to the start of the headers.
  iderrs= !odd_parity[q[2]] +
          !odd_parity[q[3]] +
          !odd_parity[q[46]&0xC0] +
         (!odd_parity[q[47]] || (q[47]&0x40));
  if (iderrs) {
    ndecode += iderrs;
    if (showerr)
      printf ("%08lX: bad SAA7118 header | trailer bytes: %02X %02X | %02X %02X [decode error]\n",
               addr, q[2], q[3], q[46], q[47]);
    return -1;
  }

  newline= (((unsigned int)(q[2]&0x3F)) << 3) | (((unsigned int)(q[3]&0x70)) >> 4);
  newfield= (q[2]&0x40)>>6;

  if  (newline < MINLINE || newline > MAXLINE) {
    ndecode++;
    if (showerr)
      printf ("%08lX: scanline %u%s is out of range (%u-%u) [decode error]\n",
               addr, newline, fieldname[newfield], MINLINE, MAXLINE);
    scanline= newline; field= newfield;
  } else {
    if (check_missing && scanline != -1 &&
        scanline >= MINLINE && scanline <= MAXLINE &&
        !(newfield == field ? (newline == scanline+1)
                            : (newline <= scanline))) {
      int bad;
      if (newfield == field && newline > scanline+1) {
        int fb= field ? 2 : 1;
        size_t i;
        bad= 0;
        for (i= scanline+1; i<newline; i++) {
          if (!(missing_lines[i]&fb)) {
            bad= 1;
            break;
          }
        }
      } else
        bad= 1;
      if (bad) {
        ndecode++;
        if (showerr)
          printf ("%08lX: jumped from scanline %u%s to %u%s [decode error]\n",
                   addr, scanline, fieldname[field], newline, fieldname[newfield]);
      }
    }
    scanline= newline; field= newfield;
    linecount[field][scanline]++;

    linetype= q[3]&0x0F;
    olinetype= linetypes[field][scanline];
    if (olinetype == -1)
      linetypes[field][scanline]= linetype;
    else if (linetype != olinetype) {
      ndecode++;
      if (showerr)
        printf ("%08lX: scanline %u%s type is '%s', but previously was '%s' [decode error]\n",
                 addr, scanline, fieldname[field], data_types[linetype], data_types[olinetype]);
    }
  }

  if (skipblank && (q[47]&0x7F) <= 2) {  // Bytecount=2 has only 2 buffer header bytes valid
    nblank++;
    if (verbose >= 2)
      printf ("%08lX L%02d%s is blank\n", addr, scanline, fieldname[field]);
    return -1;
  }

  // Decode teletext packet headers. p points to the start of the packet.
  p= q+4;
  XY= hamm16 (p, &err);
  nsoft += ((err&0x0F00)>>8); nhard += ((err&0xF000)>>12);
  if (err & 0xF000) {
    if (showerr)
      printf ("%08lX: bad MPAG %02X%02X: %u/%u soft/hard errors [hamm error]\n", addr, p[0], p[1],
               (err&0x0F00)>>8, (err&0xF000)>>12);
    return -1;
  }
  pktid.X= XY & 7;
  if (!pktid.X) pktid.X= 8;
  pktid.Y= (XY >> 3) & 0x1f;
  packetcount[pktid.Y]++;

  switch (pktid.Y) {

    case 0: {
      int b1, b2, b3, b4, wasserial;

      err= 0;
      b1= hamm16 (p+2, &err);    // page number
      b2= hamm16 (p+4, &err);    // subpage number + flags
      b3= hamm16 (p+6, &err);    // subpage number + flags
      b4= hamm16 (p+8, &err);    // language code + more flags

      wasserial= serial;
      if (badhamm (err, addr, &pktid)) {
        pktid.P= pktid_null.P;
        pktid.S= pktid_null.S;
        flags= 0; lang= 0;
      } else {
        pktid.P=    pktid.X<<8 | b1;
        pktid.S= (b3 <<8 | b2) & 0x3f7f;
        lang= b4 >> 5;
        flags=    b4 & 0x1f;
        flags |=  b3 & 0xc0;
        flags |= (b2 & 0x80) >> 2;
        serial= (flags & PG_MAGSERIAL) != 0;
      }
      pktid.D= pktid_null.D;

      PX[pktid.X]= pktid.P;
      SX[pktid.X]= pktid.S;
      flagsX[pktid.X]= flags;
      langX[pktid.X]= lang;

      checksync (addr, q, &pktid);
      if (failP (&pktid)) return 0;
      if (pktid.P == pktid_null.P) break;  // had hamm error

      if (verbose >= 0) {
        if (bypage) {
          int nshow= 0;
          size_t i;
          Page_t *page= &pages[serial ? 0 : pktid.X-1];
          Line_t *line= &page->line[0];
          if        (!wasserial &&  serial) {  // could happen if we change channel
            for (i= 0; 0<MAGAZINES; i++)
              if (pages[i].started) {
                nshow += showpage (&pages[i]);
                pages[i].started= 0;
              }
          } else if ( wasserial && !serial) {  // could happen if we change channel
            if   (pages[0].started) {
                nshow += showpage (&pages[0]);
                pages[0].started= 0;
            }
          } else if (page->started)
            nshow += showpage (page);
          page->started= 1;
          page->pktid=   pktid;
          page->lang=    lang;
          page->flags=   flags;
          if (flags & PG_ERASE)
            for (i= 1; i<=MAXROW; i++) page->line[i].present= 0;
          line->present=   1;
          line->pkt=       npkt;
          line->addr=      addr;
          line->scanline=  scanline;
          line->field=     field;
          line->timestamp= timestamp;
          memcpy (&line->frame, q, FRAMELEN);
          return nshow;
        } else {
          char prefix[9];
          sprintf (prefix, "  P%03X  ", pktid.P);
          showpkt (npkt, addr, scanline, field, timestamp, q, &pktid, prefix, 10, lang, flags);
          showhead (lang, flags);
          putchar ('\n');
          return 1;
        }
      }

      break;
    }

    case 1 ... 25: {
      pktid.P= PX[pktid.X];
      pktid.S= SX[pktid.X];
      pktid.D= pktid_null.D;
      checksync (addr, q, &pktid);
      if (failP (&pktid)) return 0;
      if (bypage && pktid.Y <= MAXROW) {
        Page_t *page= &pages[serial ? 0 : pktid.X-1];
        Line_t *line= &page->line[pktid.Y];
        line->present=  1;
        line->pkt=      npkt;
        line->addr=     addr;
        line->scanline= scanline;
        line->field=    field;
        line->timestamp=timestamp;
        memcpy (&line->frame, q, FRAMELEN);
        return 0;
      }
      lang=   langX[pktid.X];
      flags= flagsX[pktid.X];
      break;
    }

    case 26 ... 28: {
      if (failXY (&pktid)) return 0;
      pktid.P= PX[pktid.X];
      pktid.S= SX[pktid.X];
      err= 0;
      pktid.D= hamm8 (p, &err);
      if (badhamm (err, addr, &pktid)) pktid.D= pktid_null.D;
      checksync (addr, q, &pktid);
      if (failP (&pktid)) return 0;
      text= -1;
      lang=   langX[pktid.X];
      flags= flagsX[pktid.X];
      break;
    }

    case 29: {
      if (failXY (&pktid)) return 0;
      pktid.P= pktid_null.P;
      pktid.S= pktid_null.S;
      err= 0;
      pktid.D= hamm8 (p, &err);
      if (badhamm (err, addr, &pktid)) pktid.D= pktid_null.D;
      checksync (addr, q, &pktid);
      if (failP (&pktid)) return 0;
      text= -1;
      break;
    }

    case 30: {
      int b1, b2, b3, b4;

      if (!(dotimestamp && pktid.X == 8) && failXY (&pktid)) return 0;
      pktid.P= pktid_null.P;
      pktid.S= pktid_null.S;
      if (pktid.X != 8) {
        pktid.D= pktid_null.D;
        break;
      }

      err= 0;
      b1= hamm8  (p+2, &err);          // designation code
      if (badhamm (err, addr, &pktid))
        pktid.D= pktid_null.D;
      else
        pktid.D= (b1&0x0E) >> 1;

      checksync (addr, q, &pktid);
      if (!(dotimestamp && pktid.D==0) && failP (&pktid)) return 0;

      err= 0;
      b2= hamm16 (p+3, &err);          // initial page
      b3= hamm16 (p+5, &err);          // initial subpage + mag
      b4= hamm16 (p+7, &err);          // initial subpage + mag

      if (!badhamm (err, addr, &pktid)) {
        if (b2 == 0xFF) {
          index.X= pktid_null.X; index.P= pktid_null.P;
        } else {
          index.X= ((b3&0x80) >> 7) | ((b4&0x60) >> 5);
          if (!index.X) index.X= 8;
          index.P= index.X << 8 | b2;
        }
        index.S= (b4 << 8 | b3) & 0x3F7F;
        if (index.S == 0x3F7F) index.S= pktid_null.S;
      }

      if        (pktid.D == 0) {   // Format 1: Broadcast Service Data Packet (BSDP)

        time_t mjd, hh, mm, ss;
        unsigned short nig;

        nig=  revbits[p[9]] << 8 | revbits[p[10]];  // actually in reverse bit order
//      nigr=         p[9]  << 8 |         p[10];   // format used here http://pdc.ro.nu/nig.html

        tz= (30*60)*((p[11]&0x3E) >> 1);  // timezone offset in seconds
        if (p[11]&0x40) tz= -tz;

        err= 0;
        mjd= 10000 * obcd ((p[12]&0x0F)|0x10, &err) +  // take upper nibble=1 so its offset value is 0
               100 * obcd  (p[13],            &err) +
                     obcd  (p[14],            &err);
        hh=          obcd  (p[15],            &err);
        mm=          obcd  (p[16],            &err);
        ss=          obcd  (p[17],            &err);

#define MJD_UNIX0 40587   /* Modified Julian Day for Unix day 0 (1-Jan-1970) */
#define SECS_PER_DAY (24*60*60)
#define MJD_MIN (LONG_MIN/SECS_PER_DAY+MJD_UNIX0-((-1)/2))  /* assume time_t is signed long int (it is for GNU libc) */
#define MJD_MAX (LONG_MAX/SECS_PER_DAY+MJD_UNIX0-1)         /* -1 to allow for any number of hh:mm:ss */
/* for 4-byte long int: this gives a range mjd=15732-65441, or 14-Dec-1901 to 18-Jan-2038. */

        if (!err && (mjd < MJD_MIN || mjd > MJD_MAX || hh > 24 || mm > 60 || ss > 60)) err++;
        if (err) {
          nsoft += err;
          if (showerr)
            printf ("%08lX: %u bad date-time in packet %X/%u.%u: %X%02X%02X-%02X:%02X:%02X [hamm error]\n",
                     addr, err, pktid.X, pktid.Y, pktid.D, p[12]&0x0F, p[13], p[14], p[15], p[16], p[17]);
        }
        timestamp= (((mjd-MJD_UNIX0)*24 + hh)*60 + mm)*60 + ss + tz;

        if (dotimestamp && failP (&pktid)) return 0;

        if (verbose >= 0) {
          int tzm;
          char prefix[5];
          size_t i;

          for (i= 0; i<4; i++) {
            Byte c= p[18+i];
            if (odd_parity[c]) {
              c &= 0x7F;
              prefix[i]= c>=' ' && c<='~' ? c : ' ';
            } else
              prefix[i]= ' ';
          }
          prefix[4]= '\0';
          showpkt (npkt, addr, scanline, field, timestamp, q, &pktid, prefix, 22, 0, 0);
          if (index.P != pktid_null.P) {
            if (index.S == pktid_null.S)
              printf (" index:P%03X",      index.P);
            else
              printf (" index:P%03X:%04X", index.P, index.S);
          }
          if (full && b1&1) sputs (" non-multiplexed");

          putchar (' ');
          print_time (timestamp);
          tzm= abs (tz) / 60;
          tzm= 100*(tzm/60) + tzm%60;
          if (tz < 0) tzm= -tzm;
          printf (" %+05d", tzm);

          if (nig) {
            const char *cname= NULL, *name= NULL;
#ifdef NIG_H
            size_t i, tablen= sizeof(nig_table)/sizeof(nig_table[0]);
            // Could do faster with a binary search...
            for (i= 0; i<tablen; i++)
              if (nig <= nig_table[i].nig) break;
            if (i < tablen && nig == nig_table[i].nig) {
              Byte ci= nig_table[i].ci;
#ifdef CI_H
              if (ci==0x42 && nig == 0xF4)
                cname= ci_name[0x2C];  // FilmFour has Irish CI but is actually UK (see CNI code spec)
              else
                cname= ci_name[ci];
#endif
              name= nig_table[i].name;
#ifdef CNI_H
              if (!name) {
                Byte ni= nig_table[i].ni;
                const char** table= cni_table[ci];
                if (table) name= table[ni];
              }
#endif
            }
#endif
            if (name) {
              printf (" %s",  name);
              if (cname) printf (" %s", cname);
              if (full) printf (  " (%04X)", nig);
            } else {
              printf (" NIG:%04X", nig);
              if (cname) printf (" (%s)", cname);
            }
          }
          putchar ('\n');

        }

      } else if (pktid.D == 1) {   // Format 2: Programme Delivery Control (PDC)

        int bad= 0;
        Byte b[7];
        Byte lci, luf, prf, pcs, mi, ci, ni, dd, mon, hh, mm, pty;
        static int havepdc[4]= {};
        static Byte pdc[4][7];

        b[0]= revbits[hamm16 (p+ 9, &err)];
        b[1]= revbits[hamm8  (p+11, &err)];
        b[2]= revbits[hamm16 (p+12, &err)];
        b[3]= revbits[hamm16 (p+14, &err)];
        b[4]= revbits[hamm16 (p+16, &err)];
        b[5]= revbits[hamm16 (p+18, &err)];
        b[6]= revbits[hamm16 (p+20, &err)];

        lci= (b[0] & 0xC0) >> 6;

        if (badhamm (err, addr, &pktid)) {
          if (pdcdelta) return 0;
          bad= 1;
        } else if (pdcdelta) {
          if (havepdc[lci] && memcmp (&pdc[lci], &b, sizeof(b)) == 0) return 0;
          memcpy (&pdc[lci], &b, sizeof(b));
          havepdc[lci]= 1;
        }

        luf= (b[0] & 0x20) >> 5;
        prf= (b[0] & 0x10) >> 4;
        pcs= (b[0] & 0x0C) >> 2;
        mi=  (b[0] & 0x02) >> 1;
        ci=   b[1]              | (b[4] & 0x03) << 2 | (b[5] & 0xC0) >> 6;
        ni=  (b[2] & 0xC0)      | (b[5] & 0x3F);
        dd=  (b[2] & 0x3E) >> 1;
        mon= (b[2] & 0x01) << 3 | (b[3] & 0xE0) >> 5;
        hh=   b[3] & 0x1F;
        mm=  (b[4] & 0xFC) >> 2;
        pty=  b[6];

        if (verbose >= 0) {
          const char *name= NULL, *cname= NULL;

          showpkt (npkt, addr, scanline, field, timestamp, q, &pktid, "    ", 22, 0, 0);
          if (index.P != pktid_null.P) {
            if (index.S == pktid_null.S)
              printf (" index:P%03X",      index.P);
            else
              printf (" index:P%03X:%04X", index.P, index.S);
          }
          if (full && b[0]&1) sputs (" non-multiplexed");
          if (bad) {
            putchar ('\n');
            return 1;  // PDC part is bad, so don't show it
          }

          if (full && verbose >= 1)
            printf (" PDC:%02X %X %02X %02X %02X %02X %02X", b[0], b[1], b[2], b[3], b[4], b[5], b[6]);
          if          (mon == 15 && dd ==  0 && hh >= 28 && mm == 63) {
            switch (hh) {
              case 28: sputs (" continuation"); break;
              case 29: sputs (" interruption"); break;
              case 30: sputs (" recording inhibit/terminate"); break;
              case 31: sputs (" timer-control"); break;
            }
          } else if (!(mon == 15 && dd == 31 && hh == 31 && mm == 63)) {
            if (mon >= 1 && mon < sizeof(month_name)/sizeof(month_name[0]))
              printf (" %2u-%s %02u:%02u", dd, month_name[mon], hh, mm);
            else
              printf (" %02u/%02u %02u:%02u", dd, mon, hh, mm);
          }
          if (ci != 0 && ni != 0) {
#ifdef CNI_H
            if (ni != 0) {
              const char** table= cni_table[ci];
              if (table) name= table[ni];
            }
#endif
#ifdef CI_H
            if (ci != 0) cname= ci_name[ci];
#endif
            if (name) {
              printf (" %s",  name);
              if (cname) printf (" %s", cname);
              if (full)  printf (  " (%02X%02X)", ci, ni);
            } else {
              printf (" CNI:%02X%02X", ci, ni);
              if (cname) printf (" (%s)", cname);
            }
          }

          if (pcs != 0) printf (", %s", pcs_name[pcs]);
          if (pty != 0) {
#ifdef PTY_H
            const char* name= pty_name[pty];
            if (name) {
              printf (", %s", name);
              if (full) printf (" (%02X)", pty);
            } else
#endif
              printf (" PTY:%02X", pty);
          }
          if (lci) printf (" LCI:%u", lci);
          if (luf) sputs  (" LUF");
          if (prf) sputs  (" PRF");
          if (mi)  sputs  (" MI");
          putchar ('\n');
        }

      }

      return 1;
    }

    default: {
      pktid.P= pktid_null.P;
      pktid.S= pktid_null.S;
      pktid.D= pktid_null.D;
      checksync (addr, q, &pktid);
      if (failP (&pktid)) return 0;
      text= -1;
      break;
    }

  }

  if (verbose >= 0) {
    showpkt (npkt, addr, scanline, field, timestamp, q, &pktid, NULL, text, lang, flags);
    putchar ('\n');
  }

  return 1;
}

static int decodebuffer (const Byte* buf, size_t n, int maxpkt, int maxsel, Addr_t bufaddr)
{
  const Byte *q, *q0, *end= buf+n;

  if (verbose >= 1)
    printf ("%08lX: decode %u bytes\n", bufaddr, n);

  for (q= q0= buf;
       maxpkt-- && maxsel && (q= findpacket (q0, end));
       q0= q+FRAMELEN) {
    Addr_t addr;
    int nshow;

    npkt++;
    if (q>q0) {
      if (npkt>1) ndecode++;  // first gap is to be expected
      if ((npkt>1 && showerr) || verbose >= 1) {
        const Byte *p;
        addr= bufaddr+(q0-buf);
        if (addr>=vbi_end) addr= vbi_start + (addr-vbi_end);
        printf ("%08lX: %s%u-byte gap:   ", addr, (npkt==1 ? "initial " : ""), q-q0);
        for (p= q0; p<q; p++)
          printf (" %02X", *p);
        if (npkt>1) sputs (" [decode error]");
        putchar ('\n');
      }
      if ((q-q0)%FRAMELEN == 0) q= q0;
    }
    addr= bufaddr+(q-buf);
    if (addr>=vbi_end) addr= vbi_start + (addr-vbi_end);
    nshow= decodepacket (q, addr);
    if (nshow > 0) {
      nsel   += nshow;
      if (maxsel >= nshow)
        maxsel -= nshow;
      else if (maxsel > 0)
        maxsel= 0;
    }

  }

  if (!q && q0!=end) {
    if (verbose >= 1) {
      const Byte *p;
      Addr_t addr= bufaddr+(q0-buf);
      if (addr>=vbi_end) addr= vbi_start + (addr-vbi_end);
      printf ("%08lX: carry over %d extra bytes:", addr, end-q0);
      for (p= q0; p<end; p++)
        printf (" %02X", *p);
      putchar ('\n');
    }
    return end-q0;
  }
  return 0;
}

static size_t readmem (int fd, void *buf, Addr_t ptr, size_t n)
{
  int nr;
  if (n==0) return n;
  if (verbose >= 1 && ptr>=vbi_start && ptr<vbi_end)  // don't print if just reading pointer
    printf ("read %u (0x%X) bytes from %08lX:%08lX\n", n, n, ptr, ptr+n-1);
  if (-1 == lseek (fd, ptr, SEEK_SET)) {
    perror ("error seeking to read kernel memory");
    exit (101);
  }
  nr= read (fd, buf, n);
  if (nr == -1) {
    perror ("error reading kernel memory");
    exit (101);
  } else if (nr != n) {
    fprintf (stderr, "read only %d of %u bytes from kernel memory %08lX:%08lX\n", nr, n, ptr, ptr+n-1);
    exit (101);
  }
  if (verbose >= 3 && ptr>=vbi_start && ptr<vbi_end)
    showbuf (ptr, buf, nr);
  return (size_t) nr;
}

static Addr_t readptr (int fd)
{
  Addr_t ptr;
  readmem (fd, &ptr, fpga_base+16, sizeof (ptr));
  ptr |= 0x80000000;
  if (ptr<vbi_start || ptr>vbi_end) {  // can be at vbi_end too
    fprintf (stderr, "pointer %08lX is not in buffer %08lX:%08lX\n", ptr, vbi_start, vbi_end-1);
    exit (102);
  }
  return ptr;
}

static size_t readbuf (int fd, void *buf, size_t maxbuf, int old, void **start)
{
  size_t n;
  Addr_t vbi_test;

  if (start) *start= buf;
  vbi_ptr= vbi_next;

  vbi_next= readptr (fd);
  if (old) vbi_ptr= vbi_next;

  if (old || (vbi_ptr && vbi_next != vbi_ptr)) {
    if (vbi_next > vbi_ptr) {
      n= vbi_next - vbi_ptr;
      if (n>maxbuf) n= maxbuf;
      n= readmem (fd, buf, vbi_ptr, n);
    } else {
      size_t n1= vbi_end - vbi_ptr;
      size_t n2= vbi_next - vbi_start;
      if (n1>maxbuf) n1= maxbuf;
      n= readmem (fd, buf, vbi_ptr, n1);
      if (n1<maxbuf) {
        maxbuf -= n1;
        if (n2>maxbuf) n2= maxbuf;
        n += readmem (fd, buf+n1, vbi_start, n2);
      }
    }

    // Check that the part of the buffer we read wasn't overwritten in
    // the meantime. If it was, the most likely case is when we are reading
    // most or all of the buffer and the pointer advanced only a little.
    // To handle this case, we skip past the potentially overwritten part.
    // If our read took an unreasonably long time (eg. >3s), then all bets
    // are off.
    vbi_test= readptr (fd);
    if (vbi_test != vbi_next &&
        (vbi_next > vbi_ptr ? (vbi_test > vbi_ptr && vbi_test < vbi_next)
                            : (vbi_test > vbi_ptr || vbi_test < vbi_next))) {
      size_t nskip;
      ndecode++;
      if (vbi_test > vbi_next)
        nskip= vbi_test - vbi_next;
      else
        nskip= (vbi_end - vbi_next) + (vbi_test - vbi_start);
      if (lost >= 0) lost += nskip;
      if (n > nskip) {
        if (showerr)
          printf ("pointer changed from %08lX to %08lX while reading %u bytes - skip first %u bytes [decode error]\n",
                  vbi_next, vbi_test, n, nskip);
        if (start) *start= buf + nskip;
        n -= nskip;
      } else {
        if (showerr)
          printf ("pointer changed from %08lX to %08lX while reading %u bytes - skip whole buffer\n",
                  vbi_next, vbi_test, n);
        n= 0;
      }
    }

  } else {
    if (verbose >= 2)
      printf ("pointer unchanged at %08lX\n", vbi_next);
    n= 0;
  }
  return n;
}

static void getfpga()
{
  FILE* fp;
  char line[132], fpga_xtra[2]= "", vbi_xtra[2]= "";
  size_t iline;
  Addr_t fpga_len= 0;
  vbi_len= 0;

  if (verbose >= 2) printf ("read "FPGA_FILE"\n");
  if (!(fp= fopen (FPGA_FILE, "r"))) {
    perror ("cannot open "FPGA_FILE);
    exit (103);
  }
  for (iline= 1; fgets (line, sizeof(line), fp); iline++) {
    size_t lline= strlen (line);
    if (verbose >= 2) printf (FPGA_FILE":%02u: %s", iline, line);
    if (lline==0 || line[lline-1] != '\n')                                           continue;
    if (sscanf (line, " Standin0:%lx%lx%1s", &fpga_base, &fpga_len, fpga_xtra) == 2) continue;
    if (sscanf (line, " VBI1:%lx%lx%1s",     &vbi_start, &vbi_len,  vbi_xtra ) == 2) continue;
  }
  fclose (fp);
  if        (!fpga_len || fpga_xtra[0] != '\0') {
    fprintf (stderr, "could not find 'Standin0' field in "FPGA_FILE"\n");
    exit (104);
  } else if (!vbi_len  || vbi_xtra[0]  != '\0') {
    fprintf (stderr, "could not find 'VBI1' field in "FPGA_FILE"\n");
    exit (104);
  }
  vbi_end= vbi_start + vbi_len;
  if (verbose >= 1)
    printf (FPGA_FILE": FPGA %08lX:%08lX (%lu), VBI1 %08lX:%08lX (%lu)\n",
            fpga_base, fpga_base+fpga_len-1, fpga_len,
            vbi_start, vbi_end-1, vbi_len);
  return;
}

static void printstats()
{
  size_t i, j, ntot;
  int def;

  // For some reason, if there are more than two long longs in a printf, then
  // the third is lost. To be safe(er), we print them one at a time. 
  printf ("Selected %llu/", nsel);
  printf ("%llu packets ", npkt);
  printf ("(%llu blank) with ", nblank);
  printf ("%llu soft, ", nsoft);
  printf ("%llu hard, ", nhard);
  printf ("%llu parity, and ", nparity);
  printf ("%llu decoding errors, ", ndecode);
  printf ("slept %.3fs\n", totsecs);

  for (i= 0, ntot= 0; i<=31; i++) ntot += packetcount[i];
  if (ntot > 0) {
    sputs ("Packets:");
    for (i= 0; i<=31; i++)
      if (packetcount[i] > 0) printf (" %u:%llu", i, packetcount[i]);
    putchar ('\n');
  }

  for (i= MINLINE, def= -1; i<=MAXLINE; i++)
    for (j= 0; j<2; j++)
      if (linetypes[j][i] != -1 && linetypes[j][i] != def)
        def= (def == -1) ? linetypes[j][i] : -2;

  if (def != -1) {
    sputs ("Scan lines:");
    for (i= MINLINE; i<=MAXLINE; i++)
      for (j= 0; j<2; j++)
        if (linecount[j][i] > 0) {
          printf (" %u%s:%llu", i, fieldname[j], linecount[j][i]);
          if (def < 0) printf (" (%s)", data_types[linetypes[j][i]]);
        }
    if (def >= 0) printf (" (all %s)", data_types[def]);
    putchar ('\n');
  }
}

static void signal_handler (int signum)
{
  if (last_signal) return;
  last_signal= signum;
  longjmp (clean_exit, 1);
}

int main (int argc, char **argv) {
  int c;
  size_t i;
  const size_t maxmiss=  sizeof(missing_lines) / sizeof(missing_lines[0]);
  const size_t maxpktid= sizeof(pktid_sel)     / sizeof(pktid_sel[0]);

  // The following variables are declared volatile to prevent spurious
  // "variable might be clobbered by `longjmp'" (-Wall -O) warnings.
  // None of the variables in question is both modified in the setjmp block and
  // used after it, but GCC 2.8.1 still complains (GCC 3.4.4 would be happy).
  // (Actually it doesn't complain about buf and usecs, but that's probably an
  // accident of optimisation.)
  volatile int kmem_fd, num= 0, numsel= 0, old= 0, onlyold= 0, dowait= 0, stats= 0;
  volatile size_t lbuf;
  void* volatile buf;
  volatile double secs= 0.5;
  volatile unsigned long usecs;

  assert (maxmiss > MAXLINE);

  while ((c= getopt(argc, argv, "fpPzceboOCvqmsTn:N:t:M:h?")) != -1) {
    switch (c) {
      case 'f': full= 1;                  break;
      case 'p': bypage= 1; onlypages= 1;  break;
      case 'P': bypage= 1;                break;
      case 'z': pdcdelta= 1;              break;
      case 'c': colour= 1; addborder= 0;  break;
      case 'e': showerr= 1;               break;
      case 'b': skipblank= 0;             break;
      case 'o': old= 1;                   break;
      case 'O': old= 1; onlyold= 1;       break;
      case 'C': num= -1; numsel= -1;      break;
      case 'v': verbose++;                break;
      case 'q': verbose--;                break;
      case 'm': check_missing= 1;         break;
      case 's': stats= 1;                 break;
      case 'T': dotimestamp= 1;           break;
      case 'n': numsel= atoi (optarg);    break;
      case 'N': num=    atoi (optarg);    break;
      case 't': secs= strtod (optarg, 0); break;
      case 'M': {
        const char *p= optarg;
        unsigned long m;
        check_missing= 1;
        for (;;) {
          const char* q= 0;
          int frame= 3;
          m= strtoul (p, (char**) &q, 10);
          assert (q!=0);
          if (*q == 'o' || *q == 'O') { q++; frame= 1; }
          if (*q == 'e' || *q == 'E') { q++; frame= 2; }
          if (q==p || m < MINLINE || m > MAXLINE || (*q != ',' && *q != '\0')) {
            fprintf (stderr, "invalid line number list: -M %s\n", optarg);
            exit (2);
          }
          missing_lines[m]= frame;
          if (*q == '\0') break;
          p= q+1;
        }
        if (verbose >= 2) {
          sputs ("don't warn about missing lines:");
          for (i= MINLINE; i<=MAXLINE; i++) {
            if (missing_lines[i]&1) printf (" %uo", i);
            if (missing_lines[i]&2) printf (" %ue", i);
          }
          putchar ('\n');
        }
        break;
      }
      default: {
        usage (argv[0]);
        exit (1);
        break;
      }
    }
  }
  argc -= optind;
  argv += optind;

  if (argc > 0) {
    pktid_sel= (Pktid_t*) malloc (argc * sizeof (Pktid_t));
    assert (pktid_sel!=0);
    for (i= 0; i<argc; i++) {
      const char *p= argv[i];
      Pktid_t pktid= pktid_null;
      int bad= 0;

      if (npktid_sel >= maxpktid-1) {
        fprintf (stderr, "too many page specifyers: maximum is %u\n", maxpktid);
        exit (3);
      }
      if (*p == 'X' || *p == 'x') {
        p++;
        if (*p >= '1' && *p <= '8' && !isdigit (p[1]))
          pktid.X= ((*p++)-'0');
        else
          bad= 1;
      } else {
        if (*p == 'P' || *p == 'p') p++;
        if (isdigit (*p)) {
          const char *q= 0;
          unsigned long P;
          P= strtoul (p, (char**) &q, 16);
          assert (q!=0);
          if (q-p == 3 && P >= 0x100 && P <= 0x8FF) {
            pktid.P= P;
            pktid.X= (P & 0xF00) >> 8;
          } else
            bad= 1;
          p= q;
        }
      }
      if (*p == ':') {
        const char *q= 0;
        unsigned long S;
        p++;
        S= strtoul (p, (char**) &q, 16);
        assert (q!=0);
        if (q>p && q-p <= 4)
          pktid.S= S;
        else
          bad= 1;
        p= q;
      }
      if (*p == '/') {
        const char *q= 0;
        unsigned long Y;
        p++;
        Y= strtoul (p, (char**) &q, 10);
        assert (q!=0);
        if (q>p && Y <= 31)
          pktid.Y= Y;
        else
          bad= 1;
        p= q;
      }
      if (*p == '.') {
        const char *q= 0;
        unsigned long D;
        p++;
        D= strtoul (p, (char**) &q, 10);
        assert (q!=0);
        if (q>p)
          pktid.D= D;
        else
          bad= 1;
        p= q;
      }
      if (bad || *p != '\0' || p-argv[i] < 2) {
        fprintf (stderr, "bad page specifyer: %s\n", argv[i]);
        exit (3);
      }
      pktid_sel[npktid_sel++]= pktid;
    }

    if (verbose >= 2) {
      sputs ("Select pages:");
      for (i= 0; i<npktid_sel; i++) {
        putchar (' ');
        if      (pktid_sel[i].P != pktid_null.P) printf ("P%03X", pktid_sel[i].P);
        else if (pktid_sel[i].X != pktid_null.X) printf ("X%X",   pktid_sel[i].X);
        if      (pktid_sel[i].S != pktid_null.S) printf (":%04X", pktid_sel[i].S);
        if      (pktid_sel[i].Y != pktid_null.Y) printf ("/%d",   pktid_sel[i].Y);
        if      (pktid_sel[i].D != pktid_null.D) printf (".%d",   pktid_sel[i].D);
      }
      putchar ('\n');
    }
  }

  for (i= MINLINE; i<=MAXLINE; i++) {
    linetypes[0][i]= -1;
    linetypes[1][i]= -1;
  }

  getfpga();

  if (num==0 && numsel==0) numsel= (onlypages ? 1 : 25);
  if (num!=0 && numsel==0) numsel= -1;
  if (num==0 && numsel!=0) num=    -1;
  if (num>0) {
    lbuf= (FRAMELEN+2)*num + 1024;  // actually expect to need FRAMELEN*num, but get a bit more to allow for gaps
    if (lbuf>vbi_len) lbuf= vbi_len;
  } else
    lbuf= vbi_len;

  if (secs<0.0) secs= 0.0;
  usecs= 1000000.0*secs;

  buf= malloc (lbuf);
  assert (buf!=NULL);
  if (bypage) {
    pages= malloc (MAGAZINES*sizeof(Page_t));
    assert (pages!=NULL);
  } else
    pages= NULL;

  if (-1 == (kmem_fd= open(KMEM_FILE, O_RDONLY))) {
    perror ("cannot open "KMEM_FILE);
    exit (105);
  }

  if (!setjmp (clean_exit)) {
    int left= 0;
    size_t n= 0;
    void *start;

    signal (SIGINT,  signal_handler);
    signal (SIGTERM, signal_handler);

    if (old) {
      n= readbuf (kmem_fd, buf, lbuf, 1, &start);
      if (n>0)
        left= decodebuffer (start, n, num, numsel, vbi_ptr);
      dowait= 1;
      if (onlyold) num= 0;
    }

    while ((num < 0 || num>npkt) && (numsel < 0 || numsel>nsel)) {
      void *buf1;
      if (usecs && dowait) {
        if (verbose >= 1) printf ("wait %lu usec...", usecs);
        usleep (usecs);
        totsecs += secs;
        if (verbose >= 1) puts (" done");
      } else
        dowait= 1;

      if (left > 0 && left <= n) {
        if (left < n) memmove (buf, start+(n-left), left);
      } else
        left= 0;
      buf1= buf + left;

      n= readbuf (kmem_fd, buf1, lbuf-left, 0, &start);
      if (start==buf1) {  // include bit left from last buffer only if we didn't lose anything
        start= buf;
        n += left;
        if (n==left) continue;  // nothing new
      } else
        left= 0;
      if (n>0)
        left= decodebuffer (start, n, (num < 0 ? num : num-npkt), (numsel < 0 ? numsel : numsel-nsel), vbi_ptr-left);
    }
  } else {
    signal (SIGINT,  SIG_DFL);
    signal (SIGTERM, SIG_DFL);
    if (doing_colour) endcol();
    putchar ('\n');
  }

  free (buf);
  free (pages);
  if (stats) printstats();

  return 0;
}
