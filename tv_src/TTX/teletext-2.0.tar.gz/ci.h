/*
 * ci.h 1.0  $Id: ci.h,v 1.2 2005/08/30 23:34:06 maxwells_daemon Exp $
 * http://homepage.ntlworld.com/maxwells.daemon/tivo/teletext.html
 *
 * Based on a combination of table 2 (CNI country codes) from
 *   Programme Delivery Control (PDC) standard (ETSI EN 300 231 v1.3.1 (2003-04-16))
 *     http://webapp.etsi.org/exchangefolder/en_300231v010301p.pdf
 * and the ISO 3166 short country codes
 *   http://www.iso.org/iso/en/prods-services/iso3166ma/02iso-3166-code-lists/list-en1-semic.txt
 * Note that the former doesn't have country codes for Croatia and Slovenia,
 * so I added the country name to the channel name in nig.h.
 */

#ifndef CI_H
#define CI_H 1

static const char* ci_name[256]= {
  [0x12] = "Algeria",
  [0x13] = "Andorra",
  [0x14] = "Israel",
  [0x15] = "Italy",
  [0x16] = "Belgium",
  [0x17] = "Belarus",
  [0x18] = "Azores",
  [0x19] = "Albania",
  [0x1A] = "Austria",
  [0x1B] = "Hungary",
  [0x1C] = "Malta",
  [0x1D] = "Germany",
  [0x1E] = "Canary Islands",
  [0x1F] = "Egypt",
  [0x21] = "Greece",
  [0x22] = "Cyprus",
  [0x23] = "San Marino",
  [0x24] = "Switzerland",
  [0x25] = "Jordan",
  [0x26] = "Finland",
  [0x27] = "Luxembourg",
  [0x28] = "Bulgaria",
  [0x29] = "Denmark",
  [0x2A] = "Gibraltar",
  [0x2B] = "Iraq",
  [0x2C] = "UK",   // also 5B
  [0x2D] = "Libya",
  [0x2E] = "Romania",
  [0x2F] = "France",
  [0x31] = "Morocco",
  [0x32] = "Czech Republic",
  [0x33] = "Poland",
  [0x34] = "Vatican",
  [0x35] = "Slovakia",
  [0x36] = "Syria",
  [0x37] = "Tunisia",
  [0x38] = "Martinique",
  [0x39] = "Liechtenstein",
  [0x3A] = "Iceland",
  [0x3B] = "Monaco",
  [0x3E] = "Spain",
  [0x3F] = "Norway",
  [0x42] = "Ireland",
  [0x43] = "Turkey",
  [0x46] = "Yugoslavia",
  [0x47] = "Ukraine",
  [0x48] = "Netherlands",
  [0x4A] = "Lebanon",
  [0x4E] = "Sweden",
  [0x57] = "Russia",
  [0x58] = "Portugal",
  [0x5B] = "UK",   // also 2C
};

#endif
