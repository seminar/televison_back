/*
 * names.h 1.0  $Id: names.h,v 1.9 2005/08/30 23:34:07 maxwells_daemon Exp $
 * http://homepage.ntlworld.com/maxwells.daemon/tivo/teletext.html
 */

#ifndef NAMES_H
#define NAMES_H 1

#ifdef SMALL
#define NO_PTY_H
#define NO_CI_H
#define NO_CNI_H
#define NO_NIG_H
#endif

#ifndef NO_PTY_H
#include "pty.h"
#endif
#ifndef NO_CI_H
#include "ci.h"
#endif
#ifndef NO_CNI_H
#include "cni.h"
#endif
#ifndef NO_NIG_H
#include "nig.h"
#endif

static const char* fieldname[2]= {"o", "e"};  // field=0 is called "field 1 (odd)", field=1 is called "field 2 (even)"

static const char* languages[8]= {
  "English",
  "German",
  "Swedish",
  "Italian",
  "French",
  "Spanish",
  "Czech",
  "Rumanian"
};

static const char* data_types[16]= {
  "teletext EuroWST, CCST",
  "European closed caption",
  "Video Programming Service (VPS)",
  "wide screen signalling bits",
  "US teletext (WST)",
  "US closed caption (line 21)",
  "video component signal, VBI region",
  "CVBS data",
  "teletext",
  "VITC/EBU time codes (Europe)",
  "VITC/SMPTE time codes (USA)",
  "reserved data type",
  "US NABTS",
  "MOJI (Japanese)",
  "Japanese format switch (L20/22)",
  "video component signal, active video region"
};

#define PG_SUPPHEADER   0x01    // C7  row 0 is not to be displayed
#define PG_UPDATE       0x02    // C8  row 1-28 has modified (editors flag)
#define PG_OUTOFSEQ     0x04    // C9  page out of numerical order
#define PG_NODISPLAY    0x08    // C10 rows 1-24 is not to be displayed
#define PG_MAGSERIAL    0x10    // C11 serial transmission (any new header terminates page)
#define PG_ERASE        0x20    // C4  clear previously stored lines
#define PG_NEWSFLASH    0x40    // C5  box it and insert into normal video picture
#define PG_SUBTITLE     0x80    // C6  box it and insert into normal video picture

static const char* header_bits[8]= {
  "no header",    // C7  row 0 is not to be displayed
  "update",       // C8  row 1-28 has modified (editors flag)
  "out of seq",   // C9  page out of numerical order
  "inhibit",      // C10 rows 1-24 is not to be displayed
  "serial"        // C11 serial transmission (any new header terminates page)
  "erase",        // C4  clear previously stored lines
  "newsflash",    // C5  box it and insert into normal video picture
  "subtitle",     // C6  box it and insert into normal video picture
};

static const char* pcs_name[4]= {
  "stereo unknown",
  "mono",
  "stereo",
  "dual sound",
};

static const char* month_name[13]= {
  NULL,
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
};

#endif
